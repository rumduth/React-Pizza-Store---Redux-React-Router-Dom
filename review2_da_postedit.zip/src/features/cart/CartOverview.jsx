// src/features/cart/CartOverview.jsx
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { useState } from "react";  // Added for modal state

function CartOverview() {
  const cart = useSelector((state) => state.cart.cart);
  const totalPrices = cart.reduce((prev, cur) => cur.totalPrice + prev, 0);
  const [isModalOpen, setIsModalOpen] = useState(false);  // State to toggle modal

  const toggleModal = () => setIsModalOpen(!isModalOpen);

  // If cart is empty, button shows $0 and modal handles empty state
  return (
    <>
      <button
        onClick={toggleModal}
        className="fixed bottom-4 right-4 z-20 flex h-12 w-12 items-center justify-center rounded-full bg-stone-600 text-sm font-bold text-white shadow-lg hover:bg-stone-700 focus:outline-none md:h-16 md:w-16 md:text-base"
      >
        ${totalPrices.toFixed(0)}  {/* Show only total price, rounded to whole number */}
      </button>

      {/* Modal Overlay - Shows on button click */}
      {isModalOpen && (
        <div
          className="fixed inset-0 z-30 flex items-center justify-center bg-black bg-opacity-50"
          onClick={toggleModal}  // Close on outside click
        >
          <div
            className="relative m-4 max-h-[80vh] w-full max-w-md overflow-y-auto rounded-lg bg-white p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}  // Prevent closing when clicking inside
          >
            <button
              className="absolute right-2 top-2 text-gray-500 hover:text-gray-700"
              onClick={toggleModal}
            >
              &times;  {/* Close button */}
            </button>
            <h2 className="mb-4 text-lg font-bold">Your Cart</h2>
            {cart.length > 0 ? (
              <>
                <ul className="mb-4 space-y-2">
                  {cart.map((item) => (
                    <li key={item.pizzaId} className="flex justify-between">
                      <span>{item.name} x{item.quantity}</span>
                      <span>${item.totalPrice.toFixed(2)}</span>
                    </li>
                  ))}
                </ul>
                <p className="mb-4 font-semibold">Total: ${totalPrices.toFixed(2)}</p>
                <Link
                  to="/cart"
                  className="block rounded bg-blue-500 py-2 text-center text-white hover:bg-blue-600"
                  onClick={toggleModal}  // Close modal on navigation
                >
                  Go to Full Cart
                </Link>
              </>
            ) : (
              <p className="text-center text-gray-600">Empty Cart</p>
            )}
          </div>
        </div>
      )}
    </>
  );
}

export default CartOverview;